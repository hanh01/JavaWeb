package com.example.hanh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DohonghanhApplicationTests {

    @Test
    void contextLoads() {
    }

}
